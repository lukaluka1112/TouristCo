import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Hotels from "./pages/Hotels";
import Cars from "./pages/Cars";
import Restaurants from "./pages/Restaurants";
import ToursPage from "./components/ToursPage";
import TourDetailPage from "./components/TourDetailPage";
import Login from "./pages/Login";
import "./index.css";
import { useState, useRef, useEffect } from "react";

export default function App() {
  const [planePosition, setPlanePosition] = useState({ x: 40, y: 10 });
  const [isFlying, setIsFlying] = useState(false);
  const [textAnimation, setTextAnimation] = useState(false);
  const logoRef = useRef(null);
  const lettersRef = useRef([]);

  const handleLogoHover = () => {
    if (!logoRef.current) return;

    const logoRect = logoRef.current.getBoundingClientRect();
    const TPosition = { x: 20, y: -20 };
    const oPosition = { x: logoRect.width - 0, y: 0 };

    setPlanePosition(TPosition);
    setIsFlying(true);
    setTextAnimation(true);

    setTimeout(() => {
      setPlanePosition(oPosition);
    }, 10);
  };

  const handleLogoLeave = () => {
    setIsFlying(false);
    setTextAnimation(false);
    setPlanePosition({ x: 40, y: 10 });
  };

  useEffect(() => {
    if (textAnimation) {
      lettersRef.current.forEach((el, i) => {
        if (el) {
          setTimeout(() => {
            el.style.opacity = "1";
            el.style.transform = "translateY(0)";
          }, i * 100);
        }
      });
    } else {
      lettersRef.current.forEach(el => {
        if (el) {
          el.style.opacity = "0";
          el.style.transform = "translateY(10px)";
        }
      });
    }
  }, [textAnimation]);

  return (
    <Router>
      <div className="app-container">
        <nav className="navbar">
          <div
            className="logo-container"
            ref={logoRef}
            onMouseEnter={handleLogoHover}
            onMouseLeave={handleLogoLeave}
          >
            <h1 className="logo">
              {"TouristCo".split("").map((letter, index) => (
                <span
                  key={index}
                  ref={el => lettersRef.current[index] = el}
                  className="logo-letter"
                  style={{
                    transitionDelay: `${index * 0.05}s`,
                    display: "inline-block",
                    width: letter === " " ? "0.3em" : "auto"
                  }}
                >
                  {letter}
                </span>
              ))}
            </h1>
            <div
              className={`airplane ${isFlying ? 'flying' : ''}`}
              style={{
                transform: `translate(${planePosition.x}px, ${planePosition.y}px) rotate(90deg)`,
                transition: isFlying ? 'transform 3.5s cubic-bezier(0.2, 0.8, 0.4, 1)' : 'none'
              }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24" height="24">
                <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
              </svg>
            </div>
          </div>

          <div className="nav-links">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/about" className="nav-link">About Us</Link>
            <Link to="/contact" className="nav-link">Contact Us</Link>
            <Link to="/Login" className="nav-link">Sign Up</Link>
          </div>
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/Hotels" element={<Hotels />} />
          <Route path="/Cars" element={<Cars />} />
          <Route path="/Restaurants" element={<Restaurants />} />
          <Route path="/tours" element={<ToursPage />} />
          <Route path="/tours/:id" element={<TourDetailPage />} />
        </Routes>
      </div>
    </Router>
  );
}
