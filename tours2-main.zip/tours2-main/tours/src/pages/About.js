import React from "react";
import "../styles/about.css";
import BatumiHero from "../assets/batumi-hero.jpg";
import AboutPhoto from "../assets/about-photo.jpg"; // ← ეს სურათი ჩაგვაქვს

function About() {
  return React.createElement(
    "div",
    { className: "about-page" },

    // Hero Section
    React.createElement(
      "div",
      {
        className: "about-hero fade-in",
        style: {
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(${BatumiHero})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }
      },
      React.createElement("h1", null, "ჩვენს შესახებ"),
      React.createElement("p", null, "შეისწავლეთ საქართველო ჩვენთან ერთად — თბილად, უსაფრთხოდ და დაუვიწყრად")
    ),

    // Content Section
    React.createElement(
      "div",
      { className: "about-content fade-in-up" },

      React.createElement(
        "div",
        { className: "about-text" },
        React.createElement("h2", null, "ვინ ვართ ჩვენ?"),
        React.createElement(
          "p",
          null,
          "ჩვენ ვართ ახალგაზრდა, ენერგიული და გამოცდილ ტურ ოპერატორთა გუნდი, რომელიც გთავაზობთ დაუვიწყარ თავგადასავლებს საქართველოს ყველაზე ლამაზ კუთხეებში — ბათუმიდან სვანეთამდე."
        ),
        React.createElement(
          "p",
          null,
          "ჩვენი მისიაა, გაგიზიაროთ საქართველო ისეთი როგორიც ის ჩვენ გვიყვარს: სტუმართმოყვარე, გემრიელი, შთამბეჭდავი და სავსე თავგადასავლებით."
        )
      ),

      React.createElement(
        "div",
        { className: "about-image" },
        React.createElement("img", {
          src: AboutPhoto,
          alt: "About Us Image"
        })
      )
    ),

    // Why Choose Us Section
    React.createElement(
      "div",
      { className: "why-us fade-in-up" },
      React.createElement("h2", null, "რატომ ჩვენთან?"),
      React.createElement(
        "ul",
        null,
        React.createElement("li", null, "✅ გამოცდილი და მეგობრული გიდები"),
        React.createElement("li", null, "✅ უსაფრთხო და კომფორტული ტრანსპორტი"),
        React.createElement("li", null, "✅ მორგებული ტურები თქვენი სურვილით"),
        React.createElement("li", null, "✅ დაუვიწყარი შთაბეჭდილებები")
      )
    )
  );
}

export default About;
