import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./cars.css";

export default function Cars() {
  const location = useLocation();
  const [activeFilter, setActiveFilter] = useState("All");
  const [selectedCar, setSelectedCar] = useState(null);
  const [bookingDates, setBookingDates] = useState({
    pickupDate: "",
    returnDate: ""
  });

  const getActiveTab = () => {
    const path = location.pathname.toLowerCase();
    if (path.includes('hotels')) return 'hotels';
    if (path.includes('cars')) return 'cars';
    if (path.includes('restaurants')) return 'restaurants';
    if (path.includes('tours')) return 'tours';
    return 'search-all';
  };

  const activeTab = getActiveTab();

  // Car rental data
  const rentalCars = [
    {
      id: 1,
      name: "Toyota Land Cruiser",
      type: "SUV",
      description: "Premium 4x4 for mountain adventures and off-road trips",
      rating: 4.8,
      price: 85,
      image: "land-cruiser",
      features: ["4WD", "Automatic", "7 Seats", "AC"],
      details: "The Toyota Land Cruiser is renowned for its exceptional off-road capabilities and durability. With a powerful V8 engine and advanced 4-wheel drive system, it can handle any terrain Georgia has to offer. Features include leather seats, premium audio system, and comprehensive safety features."
    },
    {
      id: 2,
      name: "Mercedes-Benz E-Class",
      type: "Luxury Sedan",
      description: "Premium comfort for business trips and special occasions",
      rating: 4.9,
      price: 120,
      image: "mercedes",
      features: ["Automatic", "Leather Seats", "Navigation", "Premium Sound"],
      details: "Experience luxury travel with the Mercedes-Benz E-Class. This executive sedan features heated/ventilated seats, ambient lighting, and cutting-edge driver assistance systems. Perfect for long journeys between Georgian cities in ultimate comfort."
    },
    {
      id: 3,
      name: "Hyundai Tucson",
      type: "Compact SUV",
      description: "Perfect balance of comfort and efficiency for city and countryside",
      rating: 4.7,
      price: 45,
      image: "tucson",
      features: ["Automatic", "AC", "Bluetooth", "5 Seats"],
      details: "The Hyundai Tucson offers a comfortable ride with excellent fuel efficiency. With ample cargo space and modern infotainment system, it's ideal for exploring both urban areas and countryside landscapes of Georgia."
    },
    {
      id: 4,
      name: "Lada Niva",
      type: "Off-Road",
      description: "Legendary Russian off-roader for authentic Georgian adventures",
      rating: 4.5,
      price: 35,
      image: "niva",
      features: ["4WD", "Manual", "Basic AC", "Rugged"],
      details: "The iconic Lada Niva is a no-frills off-road champion. Simple, rugged, and surprisingly capable, it's perfect for mountain villages and unpaved roads. Manual transmission gives you full control on challenging terrain."
    },
    {
      id: 5,
      name: "BMW 5 Series",
      type: "Executive Sedan",
      description: "Sporty luxury sedan for comfortable long-distance travel",
      rating: 4.8,
      price: 110,
      image: "bmw",
      features: ["Automatic", "Premium Package", "Parking Sensors", "Sunroof"],
      details: "The BMW 5 Series combines sporty handling with executive comfort. Features include adaptive suspension, heads-up display, and gesture control. Enjoy Georgian highways with its powerful yet efficient engine."
    },
    {
      id: 6,
      name: "Toyota Yaris",
      type: "Economy",
      description: "Fuel-efficient compact car for city exploration",
      rating: 4.6,
      price: 30,
      image: "yaris",
      features: ["Automatic", "AC", "Fuel Efficient", "Compact"],
      details: "Perfect for navigating narrow streets of Georgian towns, the Toyota Yaris offers exceptional fuel economy and easy parking. Features a touchscreen infotainment system with Apple CarPlay/Android Auto."
    },
    {
      id: 7,
      name: "Range Rover Sport",
      type: "Luxury SUV",
      description: "Premium SUV with exceptional comfort and off-road capability",
      rating: 4.9,
      price: 180,
      image: "range-rover",
      features: ["4WD", "Panoramic Roof", "Premium Interior", "Navigation"],
      details: "The Range Rover Sport combines British luxury with serious off-road capability. Features include terrain response system, Meridian sound system, and massage seats. Ideal for exploring Georgia in style and comfort."
    },
    {
      id: 8,
      name: "Volkswagen Golf",
      type: "Hatchback",
      description: "Versatile and practical for all types of journeys",
      rating: 4.7,
      price: 40,
      image: "golf",
      features: ["Automatic", "AC", "Spacious", "Fuel Efficient"],
      details: "The Volkswagen Golf is a versatile hatchback perfect for all types of Georgian adventures. Offers a comfortable ride, excellent build quality, and ample cargo space. Features advanced safety systems and responsive handling."
    }
  ];

  // Filter cars based on active filter
  const filteredCars = rentalCars.filter(car => {
    if (activeFilter === "All") return true;
    
    const typeMap = {
      "SUV": ["SUV", "Compact SUV", "Luxury SUV"],
      "Sedan": ["Luxury Sedan", "Executive Sedan"],
      "Luxury": ["Luxury Sedan", "Executive Sedan", "Luxury SUV"],
      "Economy": ["Economy"],
      "Off-Road": ["Off-Road"]
    };
    
    return typeMap[activeFilter]?.includes(car.type);
  });

  const handleRentNow = (car) => {
    setSelectedCar(car);
    window.scrollTo(0, 0);
  };

  const handleBackToList = () => {
    setSelectedCar(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBookingDates(prev => ({ ...prev, [name]: value }));
  };

  const handleBookingSubmit = (e) => {
    e.preventDefault();
    alert(`Booking confirmed for ${selectedCar.name}\nPickup: ${bookingDates.pickupDate}\nReturn: ${bookingDates.returnDate}`);
    // In real app: API call to process booking
  };

  if (selectedCar) {
    return (
      <div className="car-detail-container">
        <button onClick={handleBackToList} className="back-button">
          &larr; Back to Cars
        </button>
        
        <div className="car-detail-header">
          <h1>{selectedCar.name}</h1>
          <p className="subtitle">{selectedCar.type} | ${selectedCar.price}/day</p>
        </div>
        
        <div className="car-detail-content">
          <div className="car-image-container">
            <div className={`car-detail-image ${selectedCar.image}`}>
              <div className="rating">
                <span className="star">★</span> {selectedCar.rating}
              </div>
              <div className="price-tag">
                ${selectedCar.price}<span>/day</span>
              </div>
            </div>
          </div>
          
          <div className="car-info">
            <h2>Vehicle Details</h2>
            <p>{selectedCar.details}</p>
            
            <div className="features-section">
              <h3>Key Features</h3>
              <div className="features-grid">
                {selectedCar.features.map((feature, index) => (
                  <div key={index} className="feature-item">
                    <span className="feature-icon">✓</span> {feature}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="booking-form">
              <h2>Book This Vehicle</h2>
              <form onSubmit={handleBookingSubmit}>
                <div className="form-group">
                  <label>Pickup Date</label>
                  <input
                    type="date"
                    name="pickupDate"
                    value={bookingDates.pickupDate}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Return Date</label>
                  <input
                    type="date"
                    name="returnDate"
                    value={bookingDates.returnDate}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div className="price-summary">
                  <div className="price-row">
                    <span>Daily Rate:</span>
                    <span>${selectedCar.price}/day</span>
                  </div>
                  <div className="price-row">
                    <span>Estimated Total:</span>
                    <span>${selectedCar.price * 3} (for 3 days)</span>
                  </div>
                </div>
                
                <button type="submit" className="book-now-btn">
                  Confirm Booking
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="search-menu">
        <div className={`menu-item ${activeTab === 'search-all' ? 'active' : ''}`}>
          <Link to="/" className="menu-link">
            Search All
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'hotels' ? 'active' : ''}`}>
          <Link to="/hotels" className="menu-link">
            Hotels
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'cars' ? 'active' : ''}`}>
          <Link to="/cars" className="menu-link">
            Cars for Rent
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'restaurants' ? 'active' : ''}`}>
          <Link to="/restaurants" className="menu-link">
            Restaurants
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'tours' ? 'active' : ''}`}>
          <Link to="/tours" className="menu-link">
            tours
            <div className="underline" />
          </Link>
        </div>
      </div>
      
      <div className="content">
        <h1>Car Rentals in Georgia</h1>
        <p className="subtitle">
          Find the perfect vehicle for your Georgian adventure
        </p>
        
        <div className="restaurant-filters">
          {["All", "SUV", "Sedan", "Luxury", "Economy", "Off-Road"].map(filter => (
            <div 
              key={filter}
              className={`filter ${activeFilter === filter ? 'active' : ''}`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </div>
          ))}
        </div>
        
        <div className="restaurants-grid">
          {filteredCars.map(car => (
            <div className="restaurant-card" key={car.id}>
              <div className={`restaurant-image ${car.image}`}>
                <div className="rating">
                  <span className="star">★</span> {car.rating}
                </div>
                <div className="location-tag">
                  {car.type}
                </div>
                <div className="price-tag">
                  ${car.price}<span>/day</span>
                </div>
              </div>
              <div className="restaurant-details">
                <h3>{car.name}</h3>
                <p>{car.description}</p>
                <div className="specialties">
                  {car.features.map((item, index) => (
                    <span key={index} className="specialty">{item}</span>
                  ))}
                </div>
                <button 
                  className="reserve-btn"
                  onClick={() => handleRentNow(car)}
                >
                  Rent Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}