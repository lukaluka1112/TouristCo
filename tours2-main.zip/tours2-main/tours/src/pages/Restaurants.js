import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./Restaurant.css";

export default function Restaurants() {
  const location = useLocation();
  const [activeFilter, setActiveFilter] = useState("All");
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [reservationDetails, setReservationDetails] = useState({
    date: "",
    time: "19:00",
    guests: 2,
    specialRequests: ""
  });

  const getActiveTab = () => {
    const path = location.pathname.toLowerCase();
    if (path.includes('hotels')) return 'hotels';
    if (path.includes('cars')) return 'cars';
    if (path.includes('restaurants')) return 'restaurants';
    if (path.includes('tours')) return 'tours';
    return 'search-all';
  };

  const activeTab = getActiveTab();

  // Georgian restaurants data with tags
  const georgianRestaurants = [
    {
      id: 1,
      name: "Shavi Lomi",
      location: "Tbilisi",
      description: "Modern twist on traditional Georgian cuisine in a stylish setting",
      rating: 4.8,
      image: "shavi-lomi",
      specialties: ["Khinkali", "Churchkhela", "Badrijani"],
      tags: ["Tbilisi", "Modern"],
      details: "Shavi Lomi (Black Lion) offers a contemporary take on Georgian classics in a beautifully restored building with a lush garden. The menu features seasonal ingredients sourced from local farmers. Signature dishes include deconstructed khinkali and smoked sulguni cheese with wild thyme honey. The restaurant has a carefully curated natural wine list showcasing Georgia's best producers.",
      address: "7/9 Mikheil Zandukeli Dead End, Tbilisi 0108",
      hours: "12:00 PM - 11:00 PM (Daily)",
      phone: "+995 32 299 1818"
    },
    {
      id: 2,
      name: "Barbarestan",
      location: "Tbilisi",
      description: "Fine dining experience with recipes from a 19th century cookbook",
      rating: 4.9,
      image: "barbarestan",
      specialties: ["Chakapuli", "Khachapuri", "Satsivi"],
      tags: ["Tbilisi", "Fine Dining", "Traditional"],
      details: "Barbarestan takes its name from Barbare Jorjadze, a 19th-century Georgian feminist and author of the first Georgian cookbook. The restaurant meticulously recreates recipes from her 1914 publication. Set in a charming cellar with antique furnishings, it offers an elegant dining experience. The wine list features rare Georgian vintages, and service includes detailed explanations of each historical dish.",
      address: "132 Aghmashenebeli Ave, Tbilisi 0102",
      hours: "1:00 PM - 11:00 PM (Closed Sundays)",
      phone: "+995 32 299 9595"
    },
    {
      id: 3,
      name: "Machakhela",
      location: "Batumi",
      description: "Authentic Adjarian cuisine with stunning Black Sea views",
      rating: 4.7,
      image: "machakhela",
      specialties: ["Adjarian Khachapuri", "Elarji", "Sinori"],
      tags: ["Batumi", "Traditional"],
      details: "Machakhela specializes in the unique cuisine of Georgia's Adjara region. The restaurant offers panoramic views of the Black Sea from its terrace. Signature dishes include the iconic boat-shaped Adjarian khachapuri with molten cheese and egg, and elarji (cornmeal with cheese). The interior features traditional Adjarian woodwork, and live folk music performances enhance the dining experience on weekends.",
      address: "1 Ninoshvili St, Batumi 6000",
      hours: "11:00 AM - 11:00 PM (Daily)",
      phone: "+995 422 27 72 77"
    },
    {
      id: 4,
      name: "Old Metekhi",
      location: "Tbilisi",
      description: "Traditional dishes with panoramic views of Old Tbilisi",
      rating: 4.6,
      image: "old-metekhi",
      specialties: ["Mtsvadi", "Lobio", "Pkhali"],
      tags: ["Tbilisi", "Traditional"],
      details: "Perched on a cliff overlooking the Mtkvari River and Old Tbilisi, Old Metekhi offers breathtaking views along with authentic Georgian cuisine. The restaurant is built in a traditional Georgian style with open hearths where mtsvadi (shish kebab) is grilled over vine cuttings. Their khinkali are considered among the best in the city, and the wine cellar features over 200 Georgian varieties.",
      address: "Metekhi St, Tbilisi 0103",
      hours: "12:00 PM - 12:00 AM (Daily)",
      phone: "+995 32 277 7070"
    },
    {
      id: 5,
      name: "Kazbegi Restaurant",
      location: "Stepantsminda",
      description: "Mountain cuisine in the shadow of Mount Kazbek",
      rating: 4.5,
      image: "kazbegi",
      specialties: ["Kubdari", "Kharcho", "Gomi"],
      tags: ["Mountains", "Traditional"],
      details: "Located at the foot of Mount Kazbek, this family-run restaurant specializes in the hearty cuisine of Georgia's mountainous regions. The stone building features a massive fireplace where meats slow-cook for hours. Must-try dishes include kubdari (spiced meat pie) and kharcho (beef stew with walnuts). The restaurant sources ingredients from its own farm and nearby villages.",
      address: "Main Street, Stepantsminda 4700",
      hours: "10:00 AM - 10:00 PM (Daily)",
      phone: "+995 793 45 67 89"
    },
    {
      id: 6,
      name: "Shemomechama",
      location: "Kutaisi",
      description: "Innovative takes on Imeretian culinary traditions",
      rating: 4.7,
      image: "shemomechama",
      specialties: ["Imeruli Khachapuri", "Kuchmachi", "Tklapi"],
      tags: ["Traditional"],
      details: "Shemomechama ('I accidentally ate it all') celebrates the rich culinary traditions of Georgia's Imereti region with creative presentations. The restaurant is housed in a 19th-century merchant's home with a charming courtyard. Their signature Imeruli khachapuri features a unique blend of three local cheeses, while their kuchmachi (offal dish) is considered the best in western Georgia. The menu changes seasonally based on local harvests.",
      address: "12 Tsereteli St, Kutaisi 4600",
      hours: "11:00 AM - 11:00 PM (Closed Mondays)",
      phone: "+995 431 25 55 55"
    }
  ];

  // Filter restaurants based on active filter
  const filteredRestaurants = georgianRestaurants.filter(restaurant => {
    if (activeFilter === "All") return true;
    
    // Handle special cases
    if (activeFilter === "Mountains") {
      return restaurant.tags.includes("Mountains");
    }
    
    if (activeFilter === "Traditional") {
      return restaurant.tags.includes("Traditional");
    }
    
    if (activeFilter === "Fine Dining") {
      return restaurant.tags.includes("Fine Dining");
    }
    
    return restaurant.location === activeFilter;
  });

  const handleReserveTable = (restaurant) => {
    setSelectedRestaurant(restaurant);
    window.scrollTo(0, 0);
  };

  const handleBackToList = () => {
    setSelectedRestaurant(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setReservationDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleReservationSubmit = (e) => {
    e.preventDefault();
    alert(`Reservation confirmed at ${selectedRestaurant.name}\nDate: ${reservationDetails.date}\nTime: ${reservationDetails.time}\nGuests: ${reservationDetails.guests}`);
    // In real app: API call to process reservation
  };

  if (selectedRestaurant) {
    return (
      <div className="restaurant-detail-container">
        <button onClick={handleBackToList} className="back-button">
          &larr; Back to Restaurants
        </button>
        
        <div className="restaurant-detail-header">
          <h1>{selectedRestaurant.name}</h1>
          <p className="subtitle">{selectedRestaurant.location}</p>
        </div>
        
        <div className="restaurant-detail-content">
          <div className="restaurant-image-container">
            <div className={`restaurant-detail-image ${selectedRestaurant.image}`}>
              <div className="rating">
                <span className="star">★</span> {selectedRestaurant.rating}
              </div>
            </div>
          </div>
          
          <div className="restaurant-info">
            <h2>Restaurant Overview</h2>
            <p>{selectedRestaurant.details}</p>
            
            <div className="details-grid">
              <div className="detail-item">
                <h3>Address</h3>
                <p>{selectedRestaurant.address}</p>
              </div>
              <div className="detail-item">
                <h3>Opening Hours</h3>
                <p>{selectedRestaurant.hours}</p>
              </div>
              <div className="detail-item">
                <h3>Contact</h3>
                <p>{selectedRestaurant.phone}</p>
              </div>
            </div>
            
            <div className="specialties-section">
              <h3>Signature Dishes</h3>
              <div className="specialties-grid">
                {selectedRestaurant.specialties.map((item, index) => (
                  <div key={index} className="specialty-item">
                    <span className="dish-icon">🍽️</span> {item}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="booking-form">
              <h2>Reserve Your Table</h2>
              <form onSubmit={handleReservationSubmit}>
                <div className="form-row">
                  <div className="form-group">
                    <label>Date</label>
                    <input
                      type="date"
                      name="date"
                      value={reservationDetails.date}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Time</label>
                    <select
                      name="time"
                      value={reservationDetails.time}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="12:00">12:00 PM</option>
                      <option value="12:30">12:30 PM</option>
                      <option value="13:00">1:00 PM</option>
                      <option value="13:30">1:30 PM</option>
                      <option value="14:00">2:00 PM</option>
                      <option value="18:00">6:00 PM</option>
                      <option value="18:30">6:30 PM</option>
                      <option value="19:00">7:00 PM</option>
                      <option value="19:30">7:30 PM</option>
                      <option value="20:00">8:00 PM</option>
                      <option value="20:30">8:30 PM</option>
                      <option value="21:00">9:00 PM</option>
                    </select>
                  </div>
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label>Number of Guests</label>
                    <select
                      name="guests"
                      value={reservationDetails.guests}
                      onChange={handleInputChange}
                      required
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8].map(num => (
                        <option key={num} value={num}>{num} {num === 1 ? 'guest' : 'guests'}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="form-group">
                    <label>Special Requests</label>
                    <input
                      type="text"
                      name="specialRequests"
                      value={reservationDetails.specialRequests}
                      onChange={handleInputChange}
                      placeholder="Dietary restrictions, celebrations, etc."
                    />
                  </div>
                </div>
                
                <button type="submit" className="reserve-btn">
                  Confirm Reservation
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="search-menu">
        <div className={`menu-item ${activeTab === 'search-all' ? 'active' : ''}`}>
          <Link to="/" className="menu-link">
            Search All
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'hotels' ? 'active' : ''}`}>
          <Link to="/hotels" className="menu-link">
            Hotels
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'cars' ? 'active' : ''}`}>
          <Link to="/cars" className="menu-link">
            Cars for Rent
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'restaurants' ? 'active' : ''}`}>
          <Link to="/restaurants" className="menu-link">
            Restaurants
            <div className="underline" />
          </Link>
        </div>
        <div className={`menu-item ${activeTab === 'tours' ? 'active' : ''}`}>
          <Link to="/tours" className="menu-link">
            tours
            <div className="underline" />
          </Link>
        </div>
      </div>
      
      <div className="content">
        <h1>Georgian Culinary Experience</h1>
        <p className="subtitle">
          Discover the rich flavors and traditions of Georgia's world-renowned cuisine
        </p>
        
        <div className="restaurant-filters">
          {["All", "Tbilisi", "Batumi", "Mountains", "Traditional", "Fine Dining"].map(filter => (
            <div 
              key={filter}
              className={`filter ${activeFilter === filter ? 'active' : ''}`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </div>
          ))}
        </div>
        
        <div className="restaurants-grid">
          {filteredRestaurants.map(restaurant => (
            <div className="restaurant-card" key={restaurant.id}>
              <div className={`restaurant-image ${restaurant.image}`}>
                <div className="rating">
                  <span className="star">★</span> {restaurant.rating}
                </div>
                <div className="location-tag">
                  {restaurant.location}
                </div>
              </div>
              <div className="restaurant-details">
                <h3>{restaurant.name}</h3>
                <p>{restaurant.description}</p>
                <div className="specialties">
                  {restaurant.specialties.map((item, index) => (
                    <span key={index} className="specialty">{item}</span>
                  ))}
                </div>
                <button 
                  className="reserve-btn"
                  onClick={() => handleReserveTable(restaurant)}
                >
                  Reserve a Table
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}