import { useState } from "react";
import { useParams } from "react-router-dom";
import tours from "../data/Tours.js";
import "../styles/TourDetail.css";


function TourDetailPage() {
  const { id } = useParams(); // URL-დან tourId-ის მიღება
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    date: '',
    count: '1',
    days: '1',
    cardNumber: '',
    expiry: '',
    cvc: ''
  });

  const tour = tours.find(t => t.id.toString() === id);

  
  if (!tour) {
    return <div>ტური ვერ მოიძებნა</div>;
  }

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleBooking = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setShowPayment(false);
    setFormData({
      name: '',
      phone: '',
      date: '',
      count: '1',
      days: '1',
      cardNumber: '',
      expiry: '',
      cvc: ''
    });
  };

  const handleNextStep = () => {
    const { name, phone, date, count } = formData;
    
    if (!name.trim() || !phone.trim() || !date || !count) {
      alert("გთხოვთ შეავსოთ ყველა ველი.");
      return;
    }
    
    setShowPayment(true);
  };

  const handlePayment = (e) => {
    e.preventDefault();
    const { cardNumber, expiry, cvc, name, phone, date, count, days } = formData;

    if (!cardNumber || !expiry || !cvc) {
      alert("გთხოვთ შეავსოთ გადახდის ყველა ველი.");
      return;
    }

    alert(`✅ გადახდა შესრულდა:
👤 ${name}
📞 ${phone}
📅 თარიღი: ${date}
👥 ადამიანი: ${count}
🗓️ დღეები: ${days}
💳 ბარათი: ${cardNumber}`);

    closeModal();
  };

  return (
    <div className="tour-detail fade-in">
      <img 
        src={`/${tour.image}`} 
        alt={tour.title} 
        className="tour-detail-img" 
      />
      
      <h2 className="tour-detail-title">{tour.title}</h2>
      
      <p className="tour-detail-info">რეგიონი: {tour.region}</p>
      <p className="tour-detail-info">ფასი: {tour.price} ₾</p>
      <p className="tour-detail-info">ნახვები: {tour.views}</p>
      
      <p className="tour-detail-description">
        {tour.info || "ინფორმაცია არ არის."}
      </p>
      
      <button className="book-btn" onClick={handleBooking}>
        დაჯავშნა
      </button>

      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <span className="close-btn" onClick={closeModal}>×</span>
            
            {!showPayment ? (
              // დაჯავშნის ფორმა
              <form className="booking-form">
                <h3>დაჯავშნის ფორმა</h3>
                
                <label>
                  სახელი: 
                  <input 
                    type="text" 
                    name="name" 
                    value={formData.name}
                    onChange={handleInputChange}
                    required 
                  />
                </label>
                
                <label>
                  ტელეფონი: 
                  <input 
                    type="tel" 
                    name="phone" 
                    value={formData.phone}
                    onChange={handleInputChange}
                    required 
                  />
                </label>
                
                <label>
                  თარიღი: 
                  <input 
                    type="date" 
                    name="date" 
                    value={formData.date}
                    onChange={handleInputChange}
                    required 
                  />
                </label>
                
                <label>
                  რაოდენობა: 
                  <input 
                    type="number" 
                    name="count" 
                    value={formData.count}
                    onChange={handleInputChange}
                    min="1" 
                    required 
                  />
                </label>
                
                <label>
                  ხანგრძლივობა:
                  <select 
                    name="days" 
                    value={formData.days}
                    onChange={handleInputChange}
                  >
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="5">5</option>
                    <option value="7">7</option>
                  </select> დღე
                </label>
                
                <button type="button" onClick={handleNextStep}>
                  გაგრძელება
                </button>
              </form>
            ) : (
              <div className="payment-fields">
                <h4>გადახდის ინფორმაცია</h4>
                
                <label>
                  💳 ბარათის ნომერი:
                  <input 
                    type="text" 
                    name="cardNumber" 
                    placeholder="1234 5678 9012 3456" 
                    maxLength="19" 
                    value={formData.cardNumber}
                    onChange={handleInputChange}
                    required 
                  />
                </label>
                
                <label>
                  📅 ვადა (MM/YY):
                  <input 
                    type="text" 
                    name="expiry" 
                    placeholder="08/25" 
                    maxLength="5" 
                    value={formData.expiry}
                    onChange={handleInputChange}
                    required 
                  />
                </label>
                
                <label>
                  🔒 CVC:
                  <input 
                    type="text" 
                    name="cvc" 
                    placeholder="123" 
                    maxLength="3" 
                    value={formData.cvc}
                    onChange={handleInputChange}
                    required 
                  />
                </label>
                
                <button onClick={handlePayment}>
                  გადახდა და დაჯავშნა
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default TourDetailPage;