import React from "react";
import { useNavigate } from "react-router-dom";
import "../styles/tours.css";
import "../styles/TourDetail.css";

function TourCard({ tour }) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/tour/${tour.id}`);
  };

  return (
    <div className="tour-card">
      <img src={`/images/${tour.image}`} alt={tour.title} />
      <div className="tour-title">{tour.title}</div>
      <div className="tour-footer">👁️ {tour.views} ნახვა</div>
      <button className="tour-btn" onClick={handleClick}>
        დაწვრილებით
      </button>
    </div>
  );
}

export default TourCard;
