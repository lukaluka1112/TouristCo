import React, { useState, useEffect } from "react";
import tours from "../data/Tours.js"; 
import TourCard from "../components/TourCard.js"; 

function ToursPage() {
  const [selectedRegion, setSelectedRegion] = useState("all");
  const [selectedPrice, setSelectedPrice] = useState(1000);
  const [filteredTours, setFilteredTours] = useState(tours);

  useEffect(() => {
    const filtered = tours.filter(tour => {
      const regionMatch = selectedRegion === "all" || tour.region === selectedRegion;
      const priceMatch = tour.price <= selectedPrice;
      return regionMatch && priceMatch;
    });
    setFilteredTours(filtered);
  }, [selectedRegion, selectedPrice]);

  const handleRegionChange = (e) => {
    setSelectedRegion(e.target.value);
  };

  const handlePriceChange = (e) => {
    setSelectedPrice(parseInt(e.target.value));
  };

  return (
    <div className="tours-page">
      <div className="filter-bar">
        <select value={selectedRegion} onChange={handleRegionChange}>
          <option value="all">ყველა რეგიონი</option>
          <option value="საქართველო">საქართველო</option>
          <option value="აჭარა">აჭარა</option>
          <option value="გურია">გურია</option>
          <option value="იმერეთი">იმერეთი</option>
          <option value="სამეგრელო">სამეგრელო</option>
          <option value="რაჭა">რაჭა</option>
          <option value="სვანეთი">სვანეთი</option>
          <option value="კახეთი">კახეთი</option>
          <option value="მცხეთა-მთიანეთი">მცხეთა-მთიანეთი</option>
          <option value="თუშეთი">თუშეთი</option>
          <option value="სამცხე-ჯავახეთი">სამცხე-ჯავახეთი</option>
          <option value="შიდა ქართლი">შიდა ქართლი</option>
          <option value="ხევსურეთი">ხევსურეთი</option>
          <option value="თბილისი">თბილისი</option>
          <option value="სტეფანწმინდა">სტეფანწმინდა</option>
          <option value="ბორჯომი">ბორჯომი</option>
          <option value="ქუთაისი">ქუთაისი</option>
        </select>

        <span>ბიუჯეტი: {selectedPrice} ₾</span>
        
        <input
          type="range"
          min="0"
          max="1000"
          value={selectedPrice}
          onChange={handlePriceChange}
        />
      </div>

      <div className="tour-grid">
        {filteredTours.map(tour => (
          <TourCard key={tour.id} tour={tour} />
        ))}
      </div>
    </div>
  );
}

export default ToursPage;
